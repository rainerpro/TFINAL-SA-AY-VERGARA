
DB_CONFIG = {
    'dbname': 'ahorros',
    'user': 'postgres',
    'password': '1234',
    'host': 'localhost'
}


